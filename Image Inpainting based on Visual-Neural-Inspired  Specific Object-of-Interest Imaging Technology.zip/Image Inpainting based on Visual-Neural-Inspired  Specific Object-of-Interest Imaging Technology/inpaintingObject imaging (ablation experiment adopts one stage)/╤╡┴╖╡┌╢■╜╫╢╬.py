import os
import random
from glob import glob
from PIL import Image
import numpy as np
import torch
import cv2
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
from torchvision import models
import torch.nn.functional as F

# ====================== 超参数配置 ======================
TRAIN_DIR = '残缺补全对象成像/train'
TRAIN_TARGET_DIR = '残缺补全对象成像/train'
VAL_DIR = '残缺补全对象成像/validation'
VAL_TARGET_DIR = '残缺补全对象成像/validation'
SAVE_DIR = '残缺补全对象成像/checkpoints'
os.makedirs(SAVE_DIR, exist_ok=True)

EPOCHS_PHASE3 = 40
BATCH_SIZE = 3
LR = 0.0002
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
IMG_H, IMG_W = 512, 512


# ====================== 数据加载与掩码生成 ======================
def random_mask(gt_mask, h=IMG_H, w=IMG_W):
    """只在目标对象区域内生成掩膜，覆盖范围不超过40%"""
    if gt_mask is None or np.sum(gt_mask) == 0:
        return np.zeros((h, w), np.uint8)

    mask = np.zeros_like(gt_mask, dtype=np.uint8)
    ys, xs = np.where(gt_mask > 0)
    if len(ys) == 0:
        return mask

    max_occlusion = int(len(ys) * 0.4)
    occlusion_count = 0

    # 随机矩形块
    for _ in range(random.randint(5, 15)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y, x = ys[idx], xs[idx]
        ww = min(random.randint(10, 50), w - x)
        hh = min(random.randint(10, 50), h - y)
        for i in range(y, y + hh):
            for j in range(x, x + ww):
                if i < h and j < w and gt_mask[i, j] > 0 and mask[i, j] == 0:
                    mask[i, j] = 1
                    occlusion_count += 1
                    if occlusion_count >= max_occlusion:
                        return mask

    # 随机线条
    for _ in range(random.randint(5, 10)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y1, x1 = ys[idx], xs[idx]
        length, angle = random.randint(20, 100), random.random() * 2 * np.pi
        x2 = min(max(0, int(x1 + length * np.cos(angle))), w - 1)
        y2 = min(max(0, int(y1 + length * np.sin(angle))), h - 1)
        brush = random.randint(2, 10)
        cv2.line(mask, (x1, y1), (x2, y2), 1, brush)
    return mask


class InpaintDataset(Dataset):
    def __init__(self, img_dir, tgt_dir):
        self.imgs = sorted(glob(os.path.join(img_dir, '*.jpg')))
        self.tgts = sorted(glob(os.path.join(tgt_dir, '*.jpg')))
        assert len(self.imgs) == len(self.tgts)

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, idx):
        img = Image.open(self.imgs[idx]).convert('RGB').resize((IMG_W, IMG_H))
        tgt = Image.open(self.tgts[idx]).convert('RGB').resize((IMG_W, IMG_H))
        img_np = np.array(img, np.float32) / 255.0
        tgt_np = np.array(tgt, np.float32) / 255.0

        # 生成对象区域的二值掩码
        mask = (np.max(tgt_np, axis=2) > 0).astype(np.uint8)

        # 生成遮挡掩码
        m = random_mask(mask)

        # 创建输入图像（应用遮挡）
        corrupted = img_np * (1 - m[..., None])

        # 创建权重图：对象区域权重为3，背景区域为1
        weight_map = mask.astype(np.float32) * 3 + 1  # 目标区域权重3，背景权重1

        return {
            'corrupted': torch.from_numpy(corrupted.transpose(2, 0, 1)),
            'target': torch.from_numpy(tgt_np.transpose(2, 0, 1)),
            'weight_map': torch.from_numpy(weight_map).float()  # 添加权重图
        }


# === 模型定义 ===
# 使用亚像素卷积的反卷积上采样
class SubpixelUpBlock(nn.Module):
    def __init__(self, in_ch, out_ch, scale_factor=2):
        super().__init__()
        self.conv = nn.Conv2d(in_ch, out_ch * (scale_factor ** 2), kernel_size=3, padding=1)
        self.pixel_shuffle = nn.PixelShuffle(scale_factor)
        self.act = nn.ReLU(inplace=True)  # 替换为ReLU并inplace=True

    def forward(self, x):
        x = self.conv(x)
        x = self.pixel_shuffle(x)
        return self.act(x)


class ResBlock(nn.Module):
    def __init__(self, in_ch, out_ch, k=3):
        super().__init__()
        pad = k // 2
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, k, padding=pad),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )
        self.deform_conv = nn.Conv2d(out_ch, out_ch, k, padding=pad)
        self.bn2 = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)
        self.shortcut = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 1),
            nn.BatchNorm2d(out_ch)
        ) if in_ch != out_ch else nn.Sequential()

    def forward(self, x):
        res = self.shortcut(x)
        x1 = self.conv1(x)
        x2 = self.deform_conv(x1)
        x3 = self.bn2(x2 + res)
        return self.relu(x3)


# 多尺度空洞卷积模块
class MultiScaleDilatedConv(nn.Module):
    """多尺度空洞卷积捕获纹理特征"""

    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.dila_rates = [1, 2, 4, 6]
        self.convs = nn.ModuleList()
        for rate in self.dila_rates:
            self.convs.append(
                nn.Sequential(
                    nn.Conv2d(in_ch, out_ch, kernel_size=3, dilation=rate, padding=rate),
                    nn.BatchNorm2d(out_ch),
                    nn.ReLU(inplace=True)
                )
            )
        self.fuse = nn.Sequential(
            nn.Conv2d(len(self.dila_rates) * out_ch, out_ch, kernel_size=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        outs = []
        for conv in self.convs:
            outs.append(conv(x))
        out = torch.cat(outs, dim=1)
        return self.fuse(out)


class UNetBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv(x)


class EnhancedRefiner(nn.Module):
    def __init__(self, in_ch=3, base_ch=64):
        super().__init__()
        # 输入处理模块 - 加入多尺度空洞卷积
        self.input_block = nn.Sequential(
            MultiScaleDilatedConv(in_ch, base_ch),
            MultiScaleDilatedConv(base_ch, base_ch)
        )

        # 下采样路径
        self.down1 = nn.Sequential(
            nn.Conv2d(base_ch, base_ch, 3, stride=2, padding=1),
            MultiScaleDilatedConv(base_ch, base_ch)
        )
        self.down2 = nn.Sequential(
            nn.Conv2d(base_ch, base_ch * 2, 3, stride=2, padding=1),
            MultiScaleDilatedConv(base_ch * 2, base_ch * 2)
        )
        self.down3 = nn.Sequential(
            nn.Conv2d(base_ch * 2, base_ch * 4, 3, stride=2, padding=1),
            MultiScaleDilatedConv(base_ch * 4, base_ch * 4)
        )

        # FPN模块
        self.fpn1 = nn.Sequential(
            MultiScaleDilatedConv(base_ch * 4, base_ch * 4),
            nn.Conv2d(base_ch * 4, base_ch * 4, 1)
        )
        self.fpn2 = nn.Sequential(
            MultiScaleDilatedConv(base_ch * 2, base_ch * 2),
            nn.Conv2d(base_ch * 2, base_ch * 2, 1)
        )
        self.fpn3 = nn.Sequential(
            MultiScaleDilatedConv(base_ch, base_ch),
            nn.Conv2d(base_ch, base_ch, 1)
        )

        # 特征融合层
        self.fpn1_to2 = nn.Sequential(
            nn.Conv2d(base_ch * 4, base_ch * 2, 1),
            nn.ReLU(inplace=True)
        )
        self.fpn2_to1 = nn.Sequential(
            nn.Conv2d(base_ch * 2, base_ch, 1),
            nn.ReLU(inplace=True)
        )

        # 添加特征金字塔融合层（fpn_fusion）
        self.fpn_fusion = nn.Conv2d(128, base_ch, 1)  # 添加这一行：128 -> base_ch (64) 通道

        # 上采样路径 - 重新设计以适应实际通道数
        self.up1 = SubpixelUpBlock(base_ch * 4, base_ch * 4)  # 输入256，输出256
        # 调整为接收384通道输入
        self.up2 = SubpixelUpBlock(384, base_ch * 2)  # 输入384，输出128
        # 修改上采样模块3的输入通道数：128 + 64 = 192 -> 192
        self.up3 = nn.Sequential(
            nn.Conv2d(192, base_ch * 2, 3, padding=1),  # 192 -> 128
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            nn.ReLU(inplace=True)
        )

        # 修改最终融合层的输入通道数：128 + 64 = 192 -> 192
        self.fusion_conv = nn.Conv2d(192, base_ch, kernel_size=1)

    def forward(self, x):
        x0 = self.input_block(x)  # (B, base_ch, H, W)

        x1 = self.down1(x0)  # (B, base_ch, H/2, W/2)
        x2 = self.down2(x1)  # (B, base_ch*2, H/4, W/4)
        x3 = self.down3(x2)  # (B, base_ch*4, H/8, W/8)

        # 特征金字塔处理
        f3 = self.fpn1(x3)  # (B, base_ch*4, H/8, W/8)
        f3_up = F.interpolate(self.fpn1_to2(f3), scale_factor=2, mode='bilinear', align_corners=True)

        f2 = self.fpn2(x2)  # (B, base_ch*2, H/4, W/4)
        f2_fused = f2 + f3_up  # 128 + 128 = 256? -> 不，应该是128通道，因为f3_up是128通道

        f2_up = F.interpolate(self.fpn2_to1(f2_fused), scale_factor=2, mode='bilinear', align_corners=True)
        f1 = self.fpn3(x1)  # (B, base_ch, H/2, W/2)

        # 多层特征融合
        fused_features = torch.cat([f1, f2_up], dim=1)  # (B, 64+64=128, H/2, W/2)
        fused_features = self.fpn_fusion(fused_features)  # (B, 64, H/2, W/2)

        # 上采样路径
        u3 = self.up1(f3)  # (B, 256, H/4, W/4)
        u3_cat = torch.cat([u3, f2_fused], dim=1)  # (B, 256+128=384, H/4, W/4)
        u2 = self.up2(u3_cat)  # (B, 128, H/2, W/2)

        u2_cat = torch.cat([u2, fused_features], dim=1)  # (B, 128+64=192, H/2, W/2)
        u1 = self.up3(u2_cat)  # (B, 128, H, W)

        u1_cat = torch.cat([u1, x0], dim=1)  # (B, 128+64=192, H, W)
        return self.fusion_conv(u1_cat)  # (B, 64, H, W)


class GlobalRefiner(nn.Module):
    def __init__(self, in_ch=64, base_ch=64):
        super().__init__()
        # 输入处理
        self.enc1 = UNetBlock(in_ch, base_ch)
        self.enc2 = UNetBlock(base_ch, base_ch * 2)
        self.pool = nn.MaxPool2d(2)
        self.bottleneck = UNetBlock(base_ch * 2, base_ch * 4)
        self.center = UNetBlock(base_ch * 4, base_ch * 4)

        # 使用亚像素卷积替代反卷积
        self.up2 = SubpixelUpBlock(base_ch * 4, base_ch * 2, scale_factor=2)  # 亚像素卷积上采样
        self.dec2 = UNetBlock(base_ch * 4, base_ch * 2)

        self.up1 = SubpixelUpBlock(base_ch * 2, base_ch, scale_factor=2)  # 亚像素卷积上采样
        self.dec1 = UNetBlock(base_ch * 2, base_ch)

        self.final = nn.Sequential(
            nn.Conv2d(base_ch, 3, 1),
            nn.ReLU(inplace=True)  # 确保输出范围[0,1]
        )

    def forward(self, x_feat):
        # x_feat: [B,64,512,512]
        e1 = self.enc1(x_feat)  # [B,64->64,512,512]
        e2 = self.enc2(self.pool(e1))  # [B,64->128,256,256]
        b = self.bottleneck(self.pool(e2))  # [B,128->256,128,128]
        c = self.center(b)  # [B,256,128,128]

        # 使用亚像素卷积上采样
        d2_up = self.up2(c)  # 上采样到256x256，通道数128
        d2 = self.dec2(torch.cat([d2_up, e2], dim=1))  # [B,128+128->128,256,256]

        d1_up = self.up1(d2)  # 上采样到512x512，通道数64
        d1 = self.dec1(torch.cat([d1_up, e1], dim=1))  # [B,128+64->64,512,512]

        return self.final(d1)  # [B,3,512,512]


# === 损失函数 ===
def gram_matrix(x):
    b, c, h, w = x.size()
    features = x.contiguous().view(b, c, h * w)
    G = torch.bmm(features, features.transpose(1, 2)) / (c * h * w)
    return G


class StyleLoss(nn.Module):
    def __init__(self, device):
        super().__init__()
        vgg = models.vgg16(pretrained=True).features[:4].to(device).eval()  # 仅使用前4层
        for module in vgg.modules():
            if isinstance(module, nn.ReLU):
                module.inplace = False
        self.layers = nn.ModuleList([vgg[i] for i in range(4)])
        self.mse = nn.MSELoss()

    def forward(self, pred, target):
        loss = 0.0
        x, y = pred, target
        for layer in self.layers:
            x = layer(x)
            y = layer(y)
            Gx = gram_matrix(x)
            Gy = gram_matrix(y)
            loss += self.mse(Gx, Gy)
        return loss


class PerceptualLoss(nn.Module):
    """修改后使用浅层特征的感知损失"""

    def __init__(self, device):
        super().__init__()
        # 使用预训练的VGG16特征提取器
        vgg = models.vgg16(pretrained=True).features.to(device).eval()
        for param in vgg.parameters():
            param.requires_grad = False

        # 提取浅层特征：relu1_1和relu2_1
        # VGG16结构索引：
        #   0: conv1_1, 1: relu1_1, 2: conv1_2, 3: relu1_2, 4: maxpool
        #   5: conv2_1, 6: relu2_1, 7: conv2_2, 8: relu2_2, ...
        # 使用relu1_1(索引1)和relu2_1(索引6)
        self.layer_names = ['relu1_1', 'relu2_1']
        self.layers = nn.ModuleList()

        # 提取所需层
        for i, module in enumerate(vgg):
            if i > 6:  # 只取前6层
                break
            if isinstance(module, nn.ReLU):
                module.inplace = False
            self.layers.append(module)

        self.mse = nn.MSELoss()

    def forward(self, pred, target):
        # VGG预处理 - 归一化到ImageNet均值和标准差
        mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1).to(pred.device)
        std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1).to(pred.device)
        pred = (pred - mean) / std
        target = (target - mean) / std

        # 提取浅层特征
        feat_pred = pred
        feat_target = target
        for layer in self.layers:
            feat_pred = layer(feat_pred)
            feat_target = layer(feat_target)

        # 计算感知损失
        return self.mse(feat_pred, feat_target)


def train_fusion():
    torch.autograd.set_detect_anomaly(True)

    # 初始化 EnhancedRefiner 和 GlobalRefiner
    MSR = EnhancedRefiner().to(DEVICE)
    G3 = GlobalRefiner(in_ch=64).to(DEVICE)
    print("初始化MSR和G3模型：从零开始训练")

    # 定义优化器：优化 MSR 和 G3 参数
    params = list(MSR.parameters()) + list(G3.parameters())
    optimizer = optim.Adam(params, lr=LR, betas=(0.5, 0.999))
    sched = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5, verbose=True)

    # 数据加载
    train_loader = DataLoader(InpaintDataset(TRAIN_DIR, TRAIN_TARGET_DIR),
                              BATCH_SIZE, shuffle=True, pin_memory=True, num_workers=4)
    val_loader = DataLoader(InpaintDataset(VAL_DIR, VAL_TARGET_DIR),
                            BATCH_SIZE, shuffle=False, pin_memory=True, num_workers=4)

    best_val_loss = float('inf')
    # 添加损失函数
    perc = PerceptualLoss(DEVICE)
    sty = StyleLoss(DEVICE)

    best_train_loss = float('inf')
    best_val_loss = float('inf')

    for ep in range(1, EPOCHS_PHASE3 + 1):
        # 训练阶段
        MSR.train()
        G3.train()
        train_loss = 0.0
        for b in tqdm(train_loader, desc=f"Train Epoch {ep}/{EPOCHS_PHASE3}"):
            c = b['corrupted'].to(DEVICE)
            t = b['target'].to(DEVICE)
            weight_map = b['weight_map'].to(DEVICE)
            weight_map_expanded = weight_map.unsqueeze(1)

            # 前向传播
            feat64 = MSR(c)
            pred = G3(feat64)

            # 计算基础损失
            base_loss = F.l1_loss(pred, t, reduction='none')
            weighted_loss = (base_loss * weight_map_expanded).mean()

            # 计算辅助损失
            lp = perc(pred, t)
            ls = sty(pred, t)

            # 加权总损失
            loss = (2 * weighted_loss + 50 * lp + 2 * ls)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        avg_train = train_loss / len(train_loader)
        sched.step(avg_train)

        # 验证阶段
        MSR.eval()
        G3.eval()
        val_loss = 0.0
        with torch.no_grad():
            for b in tqdm(val_loader, desc=f"Val   Epoch {ep}/{EPOCHS_PHASE3}"):
                c = b['corrupted'].to(DEVICE)
                t = b['target'].to(DEVICE)

                feat64 = MSR(c)
                pred = G3(feat64)

                l1 = F.l1_loss(pred, t)
                val_loss += l1.item()

        avg_val = val_loss / len(val_loader)
        print(f"Epoch {ep}: Train Loss {avg_train:.4f}, Val Loss {avg_val:.4f}")


        # 在第35个epoch调整学习率
        if ep == 35:
            for param_group in optimizer.param_groups:
                param_group['lr'] *= 0.1
            print(f"调整学习率至 {optimizer.param_groups[0]['lr']}")

        if avg_train <= best_train_loss and avg_val <= best_val_loss:
            best_train_loss = avg_train
            best_val_loss = avg_val
            torch.save({
                'msr': MSR.state_dict(),
                'g3': G3.state_dict(),
            }, os.path.join(SAVE_DIR, 'fusion_best.pth'))
            print(f"-- 保存最优模型 @ Epoch {ep} --")

    # 最终保存
    torch.save(MSR.state_dict(), os.path.join(SAVE_DIR, 'msr_fusion_final.pth'))
    torch.save(G3.state_dict(), os.path.join(SAVE_DIR, 'g3_fusion_final.pth'))
    print("单阶段融合训练完成")


if __name__ == '__main__':
    train_fusion()