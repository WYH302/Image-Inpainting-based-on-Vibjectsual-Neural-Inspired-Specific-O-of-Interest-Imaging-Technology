import os
import cv2
import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from glob import glob
import matplotlib.pyplot as plt
from torchvision import transforms
import random
import torch.nn.functional as F

# ====================== 配置参数 ======================
TEST_DIR = 'test'  # 测试图像目录
PRED_DIR = '修复结果输出test-predict'  # 修复结果保存目录
MASK_DIR = '随机生成的mask残缺'  # 随机遮罩保存目录
VIS_DIR = '总体可视化visualization'  # 汇总可视化目录
TRUE_DIR = 'test-true'  # 对应真值图像目录
INPUT3_DIR = '损坏图像input'  # 损坏图像保存目录

# 创建输出目录
os.makedirs(PRED_DIR, exist_ok=True)
os.makedirs(MASK_DIR, exist_ok=True)
os.makedirs(VIS_DIR, exist_ok=True)
os.makedirs(INPUT3_DIR, exist_ok=True)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
IMG_SIZE = 512

# 模型文件路径 - 现在只有一个合并模型
FUSION_MODEL_PATH = os.path.join('fusion_best.pth')  # 修改为合并后的模型文件名

IMG_H, IMG_W = 512, 512


# ====================== 图像真值处理 ======================
def find_true_mask(image_name):
    """查找与测试图像对应的真值图"""
    base_name = os.path.splitext(image_name)[0]
    possible_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']

    for ext in possible_extensions:
        true_path = os.path.join(TRUE_DIR, base_name + ext)
        if os.path.exists(true_path):
            return true_path

    return None


# ====================== 随机掩膜生成函数 ======================
def random_mask(gt_mask, h=IMG_H, w=IMG_W):
    """在目标对象区域内生成随机掩膜，覆盖范围不超过40%"""
    if gt_mask is None or np.sum(gt_mask) == 0:
        # 如果没有提供gt_mask或全黑，则在整个图像上生成随机掩膜
        gt_mask = np.ones((h, w), dtype=np.uint8)

    mask = np.zeros_like(gt_mask, dtype=np.uint8)
    ys, xs = np.where(gt_mask > 0)
    if len(ys) == 0:
        return mask

    max_occlusion = int(len(ys) * 0.4)
    occlusion_count = 0

    # 随机矩形块
    for _ in range(random.randint(5, 15)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y, x = ys[idx], xs[idx]
        ww = min(random.randint(10, 50), w - x)
        hh = min(random.randint(10, 50), h - y)
        for i in range(y, y + hh):
            for j in range(x, x + ww):
                if i < h and j < w and gt_mask[i, j] > 0 and mask[i, j] == 0:
                    mask[i, j] = 1
                    occlusion_count += 1
                    if occlusion_count >= max_occlusion:
                        return mask

    # 随机线条
    for _ in range(random.randint(5, 10)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y1, x1 = ys[idx], xs[idx]
        length, angle = random.randint(20, 100), random.random() * 2 * np.pi
        x2 = min(max(0, int(x1 + length * np.cos(angle))), w - 1)
        y2 = min(max(0, int(y1 + length * np.sin(angle))), h - 1)
        brush = random.randint(2, 10)
        cv2.line(mask, (x1, y1), (x2, y2), 1, brush)
    return mask


# === 模型定义 ===
# 使用亚像素卷积的反卷积上采样
class SubpixelUpBlock(nn.Module):
    def __init__(self, in_ch, out_ch, scale_factor=2):
        super().__init__()
        self.conv = nn.Conv2d(in_ch, out_ch * (scale_factor ** 2), kernel_size=3, padding=1)
        self.pixel_shuffle = nn.PixelShuffle(scale_factor)
        self.act = nn.ReLU(inplace=True)  # 替换为ReLU并inplace=True

    def forward(self, x):
        x = self.conv(x)
        x = self.pixel_shuffle(x)
        return self.act(x)


class ResBlock(nn.Module):
    def __init__(self, in_ch, out_ch, k=3):
        super().__init__()
        pad = k // 2
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, k, padding=pad),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )
        self.deform_conv = nn.Conv2d(out_ch, out_ch, k, padding=pad)
        self.bn2 = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)
        self.shortcut = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 1),
            nn.BatchNorm2d(out_ch)
        ) if in_ch != out_ch else nn.Sequential()

    def forward(self, x):
        res = self.shortcut(x)
        x1 = self.conv1(x)
        x2 = self.deform_conv(x1)
        x3 = self.bn2(x2 + res)
        return self.relu(x3)


# 多尺度空洞卷积模块
class MultiScaleDilatedConv(nn.Module):
    """多尺度空洞卷积捕获纹理特征"""

    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.dila_rates = [1, 2, 4, 6]
        self.convs = nn.ModuleList()
        for rate in self.dila_rates:
            self.convs.append(
                nn.Sequential(
                    nn.Conv2d(in_ch, out_ch, kernel_size=3, dilation=rate, padding=rate),
                    nn.BatchNorm2d(out_ch),
                    nn.ReLU(inplace=True)
                )
            )
        self.fuse = nn.Sequential(
            nn.Conv2d(len(self.dila_rates) * out_ch, out_ch, kernel_size=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        outs = []
        for conv in self.convs:
            outs.append(conv(x))
        out = torch.cat(outs, dim=1)
        return self.fuse(out)


class UNetBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv(x)


class EnhancedRefiner(nn.Module):
    def __init__(self, in_ch=3, base_ch=64):
        super().__init__()
        # 输入处理模块 - 加入多尺度空洞卷积
        self.input_block = nn.Sequential(
            MultiScaleDilatedConv(in_ch, base_ch),
            MultiScaleDilatedConv(base_ch, base_ch)
        )

        # 下采样路径
        self.down1 = nn.Sequential(
            nn.Conv2d(base_ch, base_ch, 3, stride=2, padding=1),
            MultiScaleDilatedConv(base_ch, base_ch)
        )
        self.down2 = nn.Sequential(
            nn.Conv2d(base_ch, base_ch * 2, 3, stride=2, padding=1),
            MultiScaleDilatedConv(base_ch * 2, base_ch * 2)
        )
        self.down3 = nn.Sequential(
            nn.Conv2d(base_ch * 2, base_ch * 4, 3, stride=2, padding=1),
            MultiScaleDilatedConv(base_ch * 4, base_ch * 4)
        )

        # FPN模块
        self.fpn1 = nn.Sequential(
            MultiScaleDilatedConv(base_ch * 4, base_ch * 4),
            nn.Conv2d(base_ch * 4, base_ch * 4, 1)
        )
        self.fpn2 = nn.Sequential(
            MultiScaleDilatedConv(base_ch * 2, base_ch * 2),
            nn.Conv2d(base_ch * 2, base_ch * 2, 1)
        )
        self.fpn3 = nn.Sequential(
            MultiScaleDilatedConv(base_ch, base_ch),
            nn.Conv2d(base_ch, base_ch, 1)
        )

        # 特征融合层
        self.fpn1_to2 = nn.Sequential(
            nn.Conv2d(base_ch * 4, base_ch * 2, 1),
            nn.ReLU(inplace=True)
        )
        self.fpn2_to1 = nn.Sequential(
            nn.Conv2d(base_ch * 2, base_ch, 1),
            nn.ReLU(inplace=True)
        )

        # 添加特征金字塔融合层（fpn_fusion）
        self.fpn_fusion = nn.Conv2d(128, base_ch, 1)  # 添加这一行：128 -> base_ch (64) 通道

        # 上采样路径 - 重新设计以适应实际通道数
        self.up1 = SubpixelUpBlock(base_ch * 4, base_ch * 4)  # 输入256，输出256
        # 调整为接收384通道输入
        self.up2 = SubpixelUpBlock(384, base_ch * 2)  # 输入384，输出128
        # 修改上采样模块3的输入通道数：128 + 64 = 192 -> 192
        self.up3 = nn.Sequential(
            nn.Conv2d(192, base_ch * 2, 3, padding=1),  # 192 -> 128
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            nn.ReLU(inplace=True)
        )

        # 修改最终融合层的输入通道数：128 + 64 = 192 -> 192
        self.fusion_conv = nn.Conv2d(192, base_ch, kernel_size=1)

    def forward(self, x):
        x0 = self.input_block(x)  # (B, base_ch, H, W)

        x1 = self.down1(x0)  # (B, base_ch, H/2, W/2)
        x2 = self.down2(x1)  # (B, base_ch*2, H/4, W/4)
        x3 = self.down3(x2)  # (B, base_ch*4, H/8, W/8)

        # 特征金字塔处理
        f3 = self.fpn1(x3)  # (B, base_ch*4, H/8, W/8)
        f3_up = F.interpolate(self.fpn1_to2(f3), scale_factor=2, mode='bilinear', align_corners=True)

        f2 = self.fpn2(x2)  # (B, base_ch*2, H/4, W/4)
        f2_fused = f2 + f3_up  # 128 + 128 = 256? -> 不，应该是128通道，因为f3_up是128通道

        f2_up = F.interpolate(self.fpn2_to1(f2_fused), scale_factor=2, mode='bilinear', align_corners=True)
        f1 = self.fpn3(x1)  # (B, base_ch, H/2, W/2)

        # 多层特征融合
        fused_features = torch.cat([f1, f2_up], dim=1)  # (B, 64+64=128, H/2, W/2)
        fused_features = self.fpn_fusion(fused_features)  # (B, 64, H/2, W/2)

        # 上采样路径
        u3 = self.up1(f3)  # (B, 256, H/4, W/4)
        u3_cat = torch.cat([u3, f2_fused], dim=1)  # (B, 256+128=384, H/4, W/4)
        u2 = self.up2(u3_cat)  # (B, 128, H/2, W/2)

        u2_cat = torch.cat([u2, fused_features], dim=1)  # (B, 128+64=192, H/2, W/2)
        u1 = self.up3(u2_cat)  # (B, 128, H, W)

        u1_cat = torch.cat([u1, x0], dim=1)  # (B, 128+64=192, H, W)
        return self.fusion_conv(u1_cat)  # (B, 64, H, W)


class GlobalRefiner(nn.Module):
    def __init__(self, in_ch=64, base_ch=64):
        super().__init__()
        # 输入处理
        self.enc1 = UNetBlock(in_ch, base_ch)
        self.enc2 = UNetBlock(base_ch, base_ch * 2)
        self.pool = nn.MaxPool2d(2)
        self.bottleneck = UNetBlock(base_ch * 2, base_ch * 4)
        self.center = UNetBlock(base_ch * 4, base_ch * 4)

        # 使用亚像素卷积替代反卷积
        self.up2 = SubpixelUpBlock(base_ch * 4, base_ch * 2, scale_factor=2)  # 亚像素卷积上采样
        self.dec2 = UNetBlock(base_ch * 4, base_ch * 2)

        self.up1 = SubpixelUpBlock(base_ch * 2, base_ch, scale_factor=2)  # 亚像素卷积上采样
        self.dec1 = UNetBlock(base_ch * 2, base_ch)

        self.final = nn.Sequential(
            nn.Conv2d(base_ch, 3, 1),
            nn.ReLU(inplace=True)  # 确保输出范围[0,1]
        )

    def forward(self, x_feat):
        # x_feat: [B,64,512,512]
        e1 = self.enc1(x_feat)  # [B,64->64,512,512]
        e2 = self.enc2(self.pool(e1))  # [B,64->128,256,256]
        b = self.bottleneck(self.pool(e2))  # [B,128->256,128,128]
        c = self.center(b)  # [B,256,128,128]

        # 使用亚像素卷积上采样
        d2_up = self.up2(c)  # 上采样到256x256，通道数128
        d2 = self.dec2(torch.cat([d2_up, e2], dim=1))  # [B,128+128->128,256,256]

        d1_up = self.up1(d2)  # 上采样到512x512，通道数64
        d1 = self.dec1(torch.cat([d1_up, e1], dim=1))  # [B,128+64->64,512,512]

        return self.final(d1)  # [B,3,512,512]


# ===== 在 EnhancedRefiner 和 GlobalRefiner 定义之后，添加以下类 =====
class FusionModel(nn.Module):
    def __init__(self, in_ch=3, base_ch=64):
        super().__init__()
        self.msr = EnhancedRefiner(in_ch, base_ch)  # MSR部分
        self.g3 = GlobalRefiner(base_ch, base_ch)  # G3部分

    def forward(self, x):
        # 首先通过MSR提取特征
        msr_feat = self.msr(x)
        # 然后通过G3生成最终输出
        final_output = self.g3(msr_feat)
        return final_output

# ====================== 加载模型 ======================
def load_model():
    # 修复路径指向训练保存的目录
    FUSION_MODEL_PATH = 'fusion_best.pth'

    if os.path.exists(FUSION_MODEL_PATH):
        # 创建模型结构
        model = FusionModel().to(DEVICE)

        # 正确加载训练保存的权重字典
        checkpoint = torch.load(FUSION_MODEL_PATH, map_location=DEVICE)

        # 分别加载两个子模型的权重
        model.msr.load_state_dict(checkpoint['msr'])
        model.g3.load_state_dict(checkpoint['g3'])

        model.eval()
        print("融合模型加载成功")
        return model
    else:
        print(f"错误: 模型文件不存在 ({FUSION_MODEL_PATH})")
        return None
# ===== 修改结束 =====

# ====================== 图像预处理 ======================
def preprocess_image(image_path, size=(IMG_SIZE, IMG_SIZE)):
    """加载并预处理图像"""
    image = Image.open(image_path).convert('RGB')
    orig_width, orig_height = image.size

    # 调整尺寸并转换张量
    transform = transforms.Compose([
        transforms.Resize(size),
        transforms.ToTensor(),  # 自动转换为[0,1]
    ])

    image_tensor = transform(image).unsqueeze(0).to(DEVICE)
    return image_tensor, orig_width, orig_height


# ===== 修改 inpaint_image() 函数 =====
def inpaint_image(model, image_tensor):
    with torch.no_grad():
        final_output = model(image_tensor)

        # 确保数值范围在[0,1]
        final_img = final_output.squeeze(0).permute(1, 2, 0)
        final_img = torch.clamp(final_img, 0, 1)  # 重要：截断到有效范围
        final_img = final_img.cpu().numpy()

        # 增加调试输出
        print(f"输出像素范围: min={final_img.min()}, max={final_img.max()}")

        return {'final': (final_img * 255).astype(np.uint8)}

# ====================== 创建可视化对比图 ======================
def create_visualization(input_img, corrupted_img, outputs, save_path):
    """创建包含多个图像的可视化对比图"""
    num_plots = 2 + len(outputs)
    plt.figure(figsize=(4 * num_plots, 4))

    # 1. 原始输入图像
    plt.subplot(1, num_plots, 1)
    plt.imshow(input_img)
    plt.title('Original Image')
    plt.axis('off')

    # 2. 损坏图像
    plt.subplot(1, num_plots, 2)
    plt.imshow(corrupted_img)
    plt.title('Corrupted Image')
    plt.axis('off')

    # 3. 各种修复结果
    for i, (name, img) in enumerate(outputs.items()):
        plt.subplot(1, num_plots, 3 + i)
        plt.imshow(img)
        plt.title(name.capitalize())
        plt.axis('off')

    # 保存和关闭
    plt.tight_layout()
    plt.savefig(save_path, bbox_inches='tight', dpi=100)
    plt.close()


# ====================== 主测试函数 ======================
def main():
    # 加载模型
    model = load_model()
    if not model:
        print("错误: 没有加载模型!")
        return

    print("模型加载成功!")

    # 获取测试图像
    test_images = sorted(glob(os.path.join(TEST_DIR, '*.jpg')) +
                         glob(os.path.join(TEST_DIR, '*.png')) +
                         glob(os.path.join(TEST_DIR, '*.jpeg')))

    # 获取所有掩膜文件路径
    mask_files = sorted(glob(os.path.join(MASK_DIR, '*.png')) +
                        glob(os.path.join(MASK_DIR, '*.jpg')) +
                        glob(os.path.join(MASK_DIR, '*.jpeg')))

    # 确保文件数量匹配
    if not mask_files:
        print(f"错误: 在 {MASK_DIR} 目录中未找到任何掩膜文件!")
        return

    # 确认两个文件夹中的文件数量相同
    if len(test_images) != len(mask_files):
        print(f"警告: 测试图像数量({len(test_images)})与掩膜文件数量({len(mask_files)})不匹配!")
        print("将按照排序后的顺序，对数量相同的部分进行配对处理")
        num_to_process = min(len(test_images), len(mask_files))
    else:
        num_to_process = len(test_images)

    # 根据文件名排序确保顺序一致
    test_images = sorted(test_images)[:num_to_process]
    mask_files = sorted(mask_files)[:num_to_process]

    print(f"开始处理 {num_to_process} 对图像/掩膜...")

    # 配对处理
    for i in range(num_to_process):
        img_path = test_images[i]
        mask_path = mask_files[i]

        img_name = os.path.basename(img_path)
        mask_name = os.path.basename(mask_path)
        base_name, ext = os.path.splitext(img_name)

        print(f"处理图像-掩膜对: {img_name} - {mask_name}")

        # 读取掩膜
        mask_img = Image.open(mask_path).convert('L')  # 转为灰度图
        mask_np = np.array(mask_img)

        # 二值化处理：确保非零像素为1
        mask = (mask_np > 0).astype(np.uint8)

        # 读取原始图像
        input_image = Image.open(img_path).convert('RGB')
        input_np = np.array(input_image)
        orig_h, orig_w = input_np.shape[:2]

        # 调整掩膜大小与原始图像一致
        if mask.shape != (orig_h, orig_w):
            mask = cv2.resize(mask, (orig_w, orig_h), interpolation=cv2.INTER_NEAREST)

        # 应用遮罩创建损坏图像（遮罩中白色区域表示遮挡）
        mask_3d = np.repeat(mask[:, :, np.newaxis], 3, axis=2)
        corrupted_np = input_np * (1 - mask_3d)  # 遮罩区域变为黑色
        corrupted_np = corrupted_np.astype(np.uint8)

        # 保存损坏图像
        corrupted_path = os.path.join(INPUT3_DIR, img_name)
        Image.fromarray(corrupted_np).save(corrupted_path)
        print(f"保存损坏图到: {corrupted_path}")

        # 为模型准备输入 (调整到512x512)
        corrupted_tensor, _, _ = preprocess_image(corrupted_path, (IMG_SIZE, IMG_SIZE))

        # 修复图像
        outputs = inpaint_image(model, corrupted_tensor)
        if not outputs:
            print("错误: 没有生成任何修复结果!")
            continue

        # 调整输出图像到原始尺寸
        resized_outputs = {}
        for name, img in outputs.items():
            # 从512x512调整回原始尺寸
            img = cv2.resize(img, (orig_w, orig_h), interpolation=cv2.INTER_CUBIC)
            resized_outputs[name] = img

            # 保存每种输出
            output_path = os.path.join(PRED_DIR, f"{base_name}_{name}{ext}")
            Image.fromarray(img).save(output_path)
            print(f"保存{name}结果到: {output_path}")

        # 创建并保存可视化结果
        vis_path = os.path.join(VIS_DIR, f"{base_name}_visual.jpg")
        create_visualization(input_np, corrupted_np, resized_outputs, vis_path)
        print(f"保存可视化结果到: {vis_path}")

    print("测试完成! 结果已保存至:")
    print(f"- 损坏图像: {INPUT3_DIR}")
    print(f"- 修复图像: {PRED_DIR}")
    print(f"- 可视化结果: {VIS_DIR}")


if __name__ == "__main__":
    main()