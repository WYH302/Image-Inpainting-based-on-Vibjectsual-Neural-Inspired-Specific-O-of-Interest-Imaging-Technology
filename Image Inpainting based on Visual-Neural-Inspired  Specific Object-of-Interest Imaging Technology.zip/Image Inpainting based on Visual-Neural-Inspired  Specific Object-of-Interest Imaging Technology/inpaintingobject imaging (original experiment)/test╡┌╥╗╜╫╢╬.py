import os
import torch
import numpy as np
from PIL import Image
from glob import glob
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import cv2
import random

# 配置参数
TEST_DIR = 'test'
TRUE_DIR = 'test-true'  # 目标对象区域的真值掩膜目录
PRED_DIR = 'test-predict2'
INPUT_DIR = 'input2'  # 存放残缺图像的目录
os.makedirs(PRED_DIR, exist_ok=True)
os.makedirs(INPUT_DIR, exist_ok=True)
os.makedirs(TRUE_DIR, exist_ok=True)  # 确保目录存在
MODEL_PATH = 'deep_model_final_epoch50.pth'
IMG_H, IMG_W = 512, 512
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 为测试设置可复现的随机种子
RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)


def find_true_mask(img_path):
    """查找与输入图像对应的真实掩膜"""
    base_name = os.path.splitext(os.path.basename(img_path))[0]

    # 在真值目录中查找可能的掩膜文件
    for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tif']:
        mask_path = os.path.join(TRUE_DIR, base_name + ext)
        if os.path.exists(mask_path):
            return mask_path
    return None


# 复现训练时的随机掩膜生成函数
def random_mask(gt_mask, h=IMG_H, w=IMG_W):
    """在目标对象区域内生成随机掩膜，覆盖范围不超过40%"""
    if gt_mask is None or np.sum(gt_mask) == 0:
        return np.zeros((h, w), np.uint8)

    mask = np.zeros_like(gt_mask, dtype=np.uint8)
    ys, xs = np.where(gt_mask > 0)
    if len(ys) == 0:
        return mask

    max_occlusion = int(len(ys) * 0.4)
    occlusion_count = 0

    # 随机矩形块
    for _ in range(random.randint(5, 15)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y, x = ys[idx], xs[idx]
        ww = min(random.randint(10, 50), w - x)
        hh = min(random.randint(10, 50), h - y)
        for i in range(y, y + hh):
            for j in range(x, x + ww):
                if i < h and j < w and gt_mask[i, j] > 0 and mask[i, j] == 0:
                    mask[i, j] = 1
                    occlusion_count += 1
                    if occlusion_count >= max_occlusion:
                        return mask

    # 随机线条
    for _ in range(random.randint(5, 10)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y1, x1 = ys[idx], xs[idx]
        length, angle = random.randint(20, 100), random.random() * 2 * np.pi
        x2 = min(max(0, int(x1 + length * np.cos(angle))), w - 1)
        y2 = min(max(0, int(y1 + length * np.sin(angle))), h - 1)
        brush = random.randint(2, 10)
        cv2.line(mask, (x1, y1), (x2, y2), 1, brush)
    return mask


# 修改后的测试数据集 - 使用目标区域的真值掩膜
class TestDataset(Dataset):
    def __init__(self, img_dir):
        self.imgs = sorted(glob(os.path.join(img_dir, '*.jpg')))

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, idx):
        img_path = self.imgs[idx]
        img_name = os.path.basename(img_path)

        # 1. 加载原始图像并归一化
        img = Image.open(img_path).convert('RGB').resize((IMG_W, IMG_H))
        img_np = np.array(img, np.float32) / 255.0

        # 2. 查找并使用真值掩膜
        true_path = find_true_mask(img_path)
        if true_path:
            # 读取真值图并转换为二值掩膜
            true_img = Image.open(true_path).convert('L')
            true_np = np.array(true_img)
            gt_mask = (true_np > 0).astype(np.uint8)
            gt_mask = cv2.resize(gt_mask, (IMG_W, IMG_H), interpolation=cv2.INTER_NEAREST)
        else:
            print(f"警告: 未找到 {img_name} 的真值图，将在整个图像上生成随机掩膜")
            # 如果没找到真值掩膜，使用整个图像作为目标区域
            gt_mask = np.ones((IMG_H, IMG_W), dtype=np.uint8)

        # 3. 生成随机遮挡掩膜
        mask = random_mask(gt_mask)
        inverted_mask = 1 - mask  # 反转：1表示保留，0表示遮挡
        inverted_mask = inverted_mask[:, :, np.newaxis]  # 增加通道维度

        # 4. 应用随机遮挡（生成残缺图像）
        masked_img = img_np * inverted_mask

        # 5. 保存残缺图像到INPUT_DIR
        masked_img_uint8 = (masked_img * 255).astype(np.uint8)
        save_path = os.path.join(INPUT_DIR, img_name)
        Image.fromarray(masked_img_uint8).save(save_path)

        # 6. 返回残缺图像（模型的输入）
        return {
            'image': torch.from_numpy(masked_img.transpose(2, 0, 1)),
            'name': img_name
        }


# 模型定义保持不变
class FFCModule(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu1 = nn.ReLU(inplace=False)
        self.conv2 = nn.Conv2d(out_channels * 2, out_channels * 2, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels * 2)
        self.relu2 = nn.ReLU(inplace=False)

    def forward(self, x):
        x = self.relu1(self.bn1(self.conv1(x)))

        # 使用 torch.rfft 代替 torch.fft.fft2 以实现向后兼容
        # 计算傅里叶变换
        x_fft = torch.rfft(x, signal_ndim=2, onesided=False)
        x_real = x_fft[..., 0]
        x_imag = x_fft[..., 1]

        x_combined = torch.cat([x_real, x_imag], dim=1)
        x_combined = self.relu2(self.bn2(self.conv2(x_combined)))
        x_real_new, x_imag_new = torch.chunk(x_combined, 2, dim=1)

        # 执行逆傅里叶变换
        complex_tensor = torch.stack([x_real_new, x_imag_new], dim=-1)
        x_ifft = torch.irfft(complex_tensor, signal_ndim=2, onesided=False)

        return x_ifft


class UNetBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv(x)


class DeepUNetGenerator(nn.Module):
    def __init__(self, in_ch=3, base_ch=64):
        super().__init__()
        # 编码器 (下采样)
        self.enc1 = UNetBlock(in_ch, base_ch)
        self.enc2 = UNetBlock(base_ch, base_ch * 2)
        self.enc3 = UNetBlock(base_ch * 2, base_ch * 4)
        self.enc4 = UNetBlock(base_ch * 4, base_ch * 8)

        self.pool = nn.MaxPool2d(2)

        # 瓶颈层
        self.bottleneck = FFCModule(base_ch * 8, base_ch * 16)

        # 解码器 (上采样)
        self.dec4 = UNetBlock(base_ch * 16, base_ch * 8)
        # 修正1: 调整转置卷积层的输入通道数
        self.up4 = nn.ConvTranspose2d(base_ch * 8, base_ch * 8, 2, stride=2)

        self.dec3 = UNetBlock(base_ch * 8 * 2, base_ch * 4)  # 注意拼接后的通道数
        self.up3 = nn.ConvTranspose2d(base_ch * 4, base_ch * 4, 2, stride=2)

        self.dec2 = UNetBlock(base_ch * 4 * 2, base_ch * 2)
        self.up2 = nn.ConvTranspose2d(base_ch * 2, base_ch * 2, 2, stride=2)

        self.dec1 = UNetBlock(base_ch * 2 * 2, base_ch)
        self.up1 = nn.ConvTranspose2d(base_ch, base_ch, 2, stride=2)

        # 最终输出层
        # 修正2: 调整最终层的输入通道数(拼接后的通道数)
        self.final = nn.Sequential(
            nn.Conv2d(base_ch * 2, base_ch, 3, padding=1),
            nn.BatchNorm2d(base_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(base_ch, 3, 1),
            nn.Tanh()  # 输出范围[-1,1]更稳定
        )

    def forward(self, img):
        # 编码路径
        e1 = self.enc1(img)
        p1 = self.pool(e1)
        e2 = self.enc2(p1)
        p2 = self.pool(e2)
        e3 = self.enc3(p2)
        p3 = self.pool(e3)
        e4 = self.enc4(p3)
        p4 = self.pool(e4)

        # 瓶颈层
        b = self.bottleneck(p4)

        # 解码路径
        d4 = self.dec4(b)
        d4_up = self.up4(d4)
        d4_concat = torch.cat([d4_up, e4], dim=1)
        d3 = self.dec3(d4_concat)
        d3_up = self.up3(d3)
        d3_concat = torch.cat([d3_up, e3], dim=1)
        d2 = self.dec2(d3_concat)
        d2_up = self.up2(d2)
        d2_concat = torch.cat([d2_up, e2], dim=1)
        d1 = self.dec1(d2_concat)
        d1_up = self.up1(d1)
        d1_concat = torch.cat([d1_up, e1], dim=1)

        # 最终输出
        out = self.final(d1_concat)
        return out

def test():
    # 准备测试数据集
    test_ds = TestDataset(TEST_DIR)
    test_loader = DataLoader(test_ds, batch_size=1, shuffle=False, num_workers=2)

    # 加载训练好的模型
    model = DeepUNetGenerator().to(DEVICE)
    model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
    model.eval()

    # 进行预测
    with torch.no_grad():
        for batch in test_loader:
            images = batch['image'].to(DEVICE)
            names = batch['name']

            # 生成预测结果
            preds = model(images)

            # 后处理并保存预测结果
            for i in range(preds.shape[0]):
                pred_img = preds[i].cpu().clamp(0, 1).permute(1, 2, 0).numpy()
                pred_img = (pred_img * 255).astype(np.uint8)
                save_path = os.path.join(PRED_DIR, names[i])
                Image.fromarray(pred_img).save(save_path)

    print(f"测试完成! 残缺图像已保存至: {INPUT_DIR}")
    print(f"预测结果已保存至: {PRED_DIR}")


if __name__ == '__main__':
    test()