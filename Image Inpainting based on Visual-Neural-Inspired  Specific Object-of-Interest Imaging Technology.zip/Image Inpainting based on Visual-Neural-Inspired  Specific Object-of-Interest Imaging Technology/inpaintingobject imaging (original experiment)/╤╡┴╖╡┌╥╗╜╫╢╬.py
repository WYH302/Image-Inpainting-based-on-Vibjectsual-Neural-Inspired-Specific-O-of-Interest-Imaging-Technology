import os
import random
from glob import glob
from PIL import Image
import numpy as np
import torch
import cv2
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm

# ----------------------- 超参数配置 -----------------------
TRAIN_DIR = '残缺补全对象成像/train'
TRAIN_TARGET_DIR = '残缺补全对象成像/train-target'
VAL_DIR = '残缺补全对象成像/validation'
VAL_TARGET_DIR = '残缺补全对象成像/validation-target'
SAVE_DIR = '残缺补全对象成像/checkpoints'
os.makedirs(SAVE_DIR, exist_ok=True)

EPOCHS_PHASE1 = 50  # 增加到50轮
BATCH_SIZE = 12
LR = 2e-4
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
IMG_H, IMG_W = 512, 512


# ----------------------- 数据加载与掩码生成 -----------------------
def random_mask(gt_mask, h=IMG_H, w=IMG_W):
    """只在目标对象区域内生成掩膜，覆盖范围不超过40%"""
    if gt_mask is None or np.sum(gt_mask) == 0:
        return np.zeros((h, w), np.uint8)

    mask = np.zeros_like(gt_mask, dtype=np.uint8)
    ys, xs = np.where(gt_mask > 0)
    if len(ys) == 0:
        return mask

    max_occlusion = int(len(ys) * 0.4)
    occlusion_count = 0

    # 随机矩形块
    for _ in range(random.randint(5, 15)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y, x = ys[idx], xs[idx]
        ww = min(random.randint(10, 50), w - x)
        hh = min(random.randint(10, 50), h - y)
        for i in range(y, y + hh):
            for j in range(x, x + ww):
                if i < h and j < w and gt_mask[i, j] > 0 and mask[i, j] == 0:
                    mask[i, j] = 1
                    occlusion_count += 1
                    if occlusion_count >= max_occlusion:
                        return mask

    # 随机线条
    for _ in range(random.randint(5, 10)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y1, x1 = ys[idx], xs[idx]
        length, angle = random.randint(20, 100), random.random() * 2 * np.pi
        x2 = min(max(0, int(x1 + length * np.cos(angle))), w - 1)
        y2 = min(max(0, int(y1 + length * np.sin(angle))), h - 1)
        brush = random.randint(2, 10)
        cv2.line(mask, (x1, y1), (x2, y2), 1, brush)
    return mask


class InpaintDataset(Dataset):
    def __init__(self, img_dir, target_dir):
        self.imgs = sorted(glob(os.path.join(img_dir, '*.jpg')))
        self.tgts = sorted(glob(os.path.join(target_dir, '*.jpg')))
        assert len(self.imgs) == len(self.tgts), '图像与目标数量不匹配'

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, idx):
        img = Image.open(self.imgs[idx]).convert('RGB').resize((IMG_W, IMG_H))
        tgt = Image.open(self.tgts[idx]).convert('RGB').resize((IMG_W, IMG_H))
        img_np = np.array(img, np.float32) / 255.0
        tgt_np = np.array(tgt, np.float32) / 255.0
        gt_mask = (np.max(tgt_np, axis=2) > 0).astype(np.uint8)
        m = random_mask(gt_mask)

        # 对输入图应用掩膜
        corrupted = img_np * (1 - m[..., None])

        # 对目标图也应用相同的掩膜 (根据您的需求新增)
        target_corrupted = tgt_np * (1 - m[..., None])

        weight_map = (np.max(target_corrupted, axis=2) > 0).astype(np.float32)

        return {
            'corrupted': torch.from_numpy(corrupted.transpose(2, 0, 1)),
            'target': torch.from_numpy(target_corrupted.transpose(2, 0, 1)),
            'weight_map': torch.from_numpy(weight_map).float()
        }


# ----------------------- 模型定义 -----------------------
class FFCModule(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu1 = nn.ReLU(inplace=True)

        self.conv2 = nn.Conv2d(out_channels * 2, out_channels * 2, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels * 2)
        self.relu2 = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.relu1(self.bn1(self.conv1(x)))
        x_fft = torch.fft.fft2(x)
        x_real, x_imag = x_fft.real, x_fft.imag
        x_combined = torch.cat([x_real, x_imag], dim=1)
        x_combined = self.relu2(self.bn2(self.conv2(x_combined)))
        x_real_new, x_imag_new = torch.chunk(x_combined, 2, dim=1)
        x_ifft = torch.fft.ifft2(torch.complex(x_real_new, x_imag_new)).real
        return x_ifft


class UNetBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv(x)


class DeepUNetGenerator(nn.Module):
    def __init__(self, in_ch=3, base_ch=64):
        super().__init__()
        # 编码器 (下采样)
        self.enc1 = UNetBlock(in_ch, base_ch)
        self.enc2 = UNetBlock(base_ch, base_ch * 2)
        self.enc3 = UNetBlock(base_ch * 2, base_ch * 4)
        self.enc4 = UNetBlock(base_ch * 4, base_ch * 8)

        self.pool = nn.MaxPool2d(2)

        # 瓶颈层
        self.bottleneck = FFCModule(base_ch * 8, base_ch * 16)

        # 解码器 (上采样)
        self.dec4 = UNetBlock(base_ch * 16, base_ch * 8)
        # 修正1: 调整转置卷积层的输入通道数
        self.up4 = nn.ConvTranspose2d(base_ch * 8, base_ch * 8, 2, stride=2)

        self.dec3 = UNetBlock(base_ch * 8 * 2, base_ch * 4)  # 注意拼接后的通道数
        self.up3 = nn.ConvTranspose2d(base_ch * 4, base_ch * 4, 2, stride=2)

        self.dec2 = UNetBlock(base_ch * 4 * 2, base_ch * 2)
        self.up2 = nn.ConvTranspose2d(base_ch * 2, base_ch * 2, 2, stride=2)

        self.dec1 = UNetBlock(base_ch * 2 * 2, base_ch)
        self.up1 = nn.ConvTranspose2d(base_ch, base_ch, 2, stride=2)

        # 最终输出层
        # 修正2: 调整最终层的输入通道数(拼接后的通道数)
        self.final = nn.Sequential(
            nn.Conv2d(base_ch * 2, base_ch, 3, padding=1),
            nn.BatchNorm2d(base_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(base_ch, 3, 1),
            nn.Tanh()  # 输出范围[-1,1]更稳定
        )

    def forward(self, img):
        # 编码路径
        e1 = self.enc1(img)
        p1 = self.pool(e1)
        e2 = self.enc2(p1)
        p2 = self.pool(e2)
        e3 = self.enc3(p2)
        p3 = self.pool(e3)
        e4 = self.enc4(p3)
        p4 = self.pool(e4)

        # 瓶颈层
        b = self.bottleneck(p4)

        # 解码路径
        d4 = self.dec4(b)
        d4_up = self.up4(d4)
        d4_concat = torch.cat([d4_up, e4], dim=1)
        d3 = self.dec3(d4_concat)
        d3_up = self.up3(d3)
        d3_concat = torch.cat([d3_up, e3], dim=1)
        d2 = self.dec2(d3_concat)
        d2_up = self.up2(d2)
        d2_concat = torch.cat([d2_up, e2], dim=1)
        d1 = self.dec1(d2_concat)
        d1_up = self.up1(d1)
        d1_concat = torch.cat([d1_up, e1], dim=1)

        # 最终输出
        out = self.final(d1_concat)
        return out


# ----------------------- 训练流程 -----------------------
def train():
    # 数据集和数据加载器
    train_ds = InpaintDataset(TRAIN_DIR, TRAIN_TARGET_DIR)
    val_ds = InpaintDataset(VAL_DIR, VAL_TARGET_DIR)

    train_loader = DataLoader(train_ds, BATCH_SIZE, shuffle=True, num_workers=4, pin_memory=True)
    val_loader = DataLoader(val_ds, BATCH_SIZE, shuffle=False, num_workers=4, pin_memory=True)

    # 模型和优化器
    G1 = DeepUNetGenerator().to(DEVICE)
    optG1 = optim.Adam(G1.parameters(), lr=LR, betas=(0.5, 0.999))
    mse = nn.MSELoss()

    # 初始化最佳损失值为正无穷
    best_train_loss = float('inf')
    best_val_loss = float('inf')
    best_epoch = 0  # 跟踪最佳模型对应的epoch

    for ep in range(1, EPOCHS_PHASE1 + 1):
        # 学习率调整：当epoch>40时降低学习率
        if ep == 41:
            for param_group in optG1.param_groups:
                param_group['lr'] = LR * 0.1
            print(f"\n已调整学习率到: {LR * 0.1} (原始学习率的0.1倍)\n")

        # ===== 训练阶段 =====
        G1.train()
        train_loss = 0.0
        pbar = tqdm(train_loader, desc=f"训练阶段 Epoch {ep}")
        for batch in pbar:
            cor = batch['corrupted'].to(DEVICE)
            tgt = batch['target'].to(DEVICE)  # 使用完整目标图

            weight_map = batch['weight_map'].to(DEVICE)

            weight_map_expanded = weight_map.unsqueeze(1)
            weight_map_expanded = weight_map_expanded * 4 + 1
            out = G1(cor)

            # 计算加权损失
            diff = out - tgt
            weighted_sq_diff = weight_map_expanded * (diff ** 2)
            loss = weighted_sq_diff.mean()

            optG1.zero_grad()
            loss.backward()
            optG1.step()

            train_loss += loss.item()
            avg_loss = train_loss / (pbar.n + 1)
            pbar.set_postfix({'训练损失': avg_loss})

        # ===== 验证阶段 =====
        G1.eval()
        val_loss = 0.0
        val_progress = tqdm(val_loader, desc=f"验证阶段 Epoch {ep}")
        with torch.no_grad():
            for batch in val_progress:
                cor = batch['corrupted'].to(DEVICE)
                tgt = batch['target'].to(DEVICE)
                pred = G1(cor)
                loss = mse(pred, tgt)
                val_loss += loss.item()
                avg_val_loss = val_loss / (val_progress.n + 1)
                val_progress.set_postfix({'验证损失': avg_val_loss})

        # 计算平均损失
        epoch_train_loss = train_loss / len(train_loader)
        epoch_val_loss = val_loss / len(val_loader)
        print(f"Epoch {ep}/{EPOCHS_PHASE1} - 训练损失: {epoch_train_loss:.6f}, 验证损失: {epoch_val_loss:.6f}")

        # 检查是否两个损失都小于之前的最佳值
        if epoch_train_loss <= best_train_loss and epoch_val_loss <= best_val_loss:
            # 更新最佳损失值
            best_train_loss = epoch_train_loss
            best_val_loss = epoch_val_loss
            best_epoch = ep

            # 保存模型
            model_path = os.path.join(SAVE_DIR,
                                      f'deep_model_best_epoch{ep}_train{epoch_train_loss:.4f}_val{epoch_val_loss:.4f}.pth')
            torch.save(G1.state_dict(), model_path)
            print(f"保存最佳模型: {model_path} (训练损失: {epoch_train_loss:.6f}, 验证损失: {epoch_val_loss:.6f})")

    # 训练结束后保存最终模型
    final_model_path = os.path.join(SAVE_DIR, f'deep_model_final_epoch{EPOCHS_PHASE1}.pth')
    torch.save(G1.state_dict(), final_model_path)
    print(f"\n训练完成！保存最终模型: {final_model_path}")
    print(f"最佳模型来自 Epoch {best_epoch} - 训练损失: {best_train_loss:.6f}, 验证损失: {best_val_loss:.6f}")


if __name__ == '__main__':
    train()