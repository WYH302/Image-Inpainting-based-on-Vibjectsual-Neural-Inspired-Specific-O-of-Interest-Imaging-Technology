import os
import cv2
import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from glob import glob
import matplotlib.pyplot as plt
from torchvision import transforms
import random
import torch.nn.functional as F
import cv2
# ----------------------- 配置参数 -----------------------
TEST_DIR = '鲁棒性实验test'  # 测试图像目录
PRED_DIR = '鲁棒性实验修复结果输出test-predict'  # 修复结果保存目录
MASK_DIR = '鲁棒性实验随机生成的mask残缺'  # 随机遮罩保存目录
VIS_DIR = '鲁棒性实验总体可视化visualization'  # 汇总可视化目录
TRUE_DIR = '鲁棒性实验test-true'  # 对应真值图像目录
INPUT3_DIR = '鲁棒性实验损坏图像input'  # 损坏图像保存目录
PHASE1_DIR = '鲁棒性实验第一阶段输出phase1'  # 第一阶段输出保存目录

# 创建输出目录
os.makedirs(PRED_DIR, exist_ok=True)
os.makedirs(MASK_DIR, exist_ok=True)
os.makedirs(VIS_DIR, exist_ok=True)
os.makedirs(INPUT3_DIR, exist_ok=True)  # 创建损坏图像目录
os.makedirs(PHASE1_DIR, exist_ok=True)  # 创建第一阶段输出目录

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
IMG_SIZE = 512
MODEL_DIR = ''  # 模型目录，根据你的实际位置调整

# 模型文件路径 - 根据你的实际文件名修改
PHASE1_MODEL_PATH = os.path.join(MODEL_DIR, 'deep_model_final_epoch50.pth')  # 第一阶段模型
MSR_MODEL_PATH = os.path.join(MODEL_DIR, 'msr_fusion_final.pth')  # 融合模型中的MSR
G3_MODEL_PATH = os.path.join(MODEL_DIR, 'g3_fusion_final.pth')  # 融合模型中的G3

IMG_H, IMG_W = 512, 512


# ----------------------- 图像真值处理 -----------------------
def find_true_mask(image_name):
    """查找与测试图像对应的真值图"""
    base_name = os.path.splitext(image_name)[0]
    possible_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']

    for ext in possible_extensions:
        true_path = os.path.join(TRUE_DIR, base_name + ext)
        if os.path.exists(true_path):
            return true_path

    # 如果找不到真值图，尝试查找带后缀的版本
    suffixes = ['_mask', '_gt', '_label', '_true', '_seg']
    for suffix in suffixes:
        for ext in possible_extensions:
            true_path = os.path.join(TRUE_DIR, f"{base_name}{suffix}{ext}")
            if os.path.exists(true_path):
                return true_path

    return None


# ----------------------- 随机掩膜生成函数 -----------------------
def random_mask(gt_mask, h=IMG_H, w=IMG_W):
    """在目标对象区域内生成随机掩膜，覆盖范围不超过40%"""
    if gt_mask is None or np.sum(gt_mask) == 0:
        # 如果没有提供gt_mask或全黑，则在整个图像上生成随机掩膜
        gt_mask = np.ones((h, w), dtype=np.uint8)

    mask = np.zeros_like(gt_mask, dtype=np.uint8)
    ys, xs = np.where(gt_mask > 0)
    if len(ys) == 0:
        return mask

    max_occlusion = int(len(ys) * 0.4)
    occlusion_count = 0

    # 随机矩形块
    for _ in range(random.randint(5, 15)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y, x = ys[idx], xs[idx]
        ww = min(random.randint(10, 50), w - x)
        hh = min(random.randint(10, 50), h - y)
        for i in range(y, y + hh):
            for j in range(x, x + ww):
                if i < h and j < w and gt_mask[i, j] > 0 and mask[i, j] == 0:
                    mask[i, j] = 1
                    occlusion_count += 1
                    if occlusion_count >= max_occlusion:
                        return mask

    # 随机线条
    for _ in range(random.randint(5, 10)):
        if occlusion_count >= max_occlusion:
            break
        idx = random.randint(0, len(ys) - 1)
        y1, x1 = ys[idx], xs[idx]
        length, angle = random.randint(20, 100), random.random() * 2 * np.pi
        x2 = min(max(0, int(x1 + length * np.cos(angle))), w - 1)
        y2 = min(max(0, int(y1 + length * np.sin(angle))), h - 1)
        brush = random.randint(2, 10)
        cv2.line(mask, (x1, y1), (x2, y2), 1, brush)
    return mask


# 模型定义保持不变
class FFCModule(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu1 = nn.ReLU(inplace=False)
        self.conv2 = nn.Conv2d(out_channels * 2, out_channels * 2, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels * 2)
        self.relu2 = nn.ReLU(inplace=False)

    def forward(self, x):
        x = self.relu1(self.bn1(self.conv1(x)))

        # 使用 torch.rfft 代替 torch.fft.fft2 以实现向后兼容
        # 计算傅里叶变换
        x_fft = torch.rfft(x, signal_ndim=2, onesided=False)
        x_real = x_fft[..., 0]
        x_imag = x_fft[..., 1]

        x_combined = torch.cat([x_real, x_imag], dim=1)
        x_combined = self.relu2(self.bn2(self.conv2(x_combined)))
        x_real_new, x_imag_new = torch.chunk(x_combined, 2, dim=1)

        # 执行逆傅里叶变换
        complex_tensor = torch.stack([x_real_new, x_imag_new], dim=-1)
        x_ifft = torch.irfft(complex_tensor, signal_ndim=2, onesided=False)

        return x_ifft


class UNetBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv(x)


class DeepUNetGenerator(nn.Module):
    def __init__(self, in_ch=3, base_ch=64):
        super().__init__()
        # 编码器 (下采样)
        self.enc1 = UNetBlock(in_ch, base_ch)
        self.enc2 = UNetBlock(base_ch, base_ch * 2)
        self.enc3 = UNetBlock(base_ch * 2, base_ch * 4)
        self.enc4 = UNetBlock(base_ch * 4, base_ch * 8)

        self.pool = nn.MaxPool2d(2)

        # 瓶颈层
        self.bottleneck = FFCModule(base_ch * 8, base_ch * 16)

        # 解码器 (上采样)
        self.dec4 = UNetBlock(base_ch * 16, base_ch * 8)
        # 修正1: 调整转置卷积层的输入通道数
        self.up4 = nn.ConvTranspose2d(base_ch * 8, base_ch * 8, 2, stride=2)

        self.dec3 = UNetBlock(base_ch * 8 * 2, base_ch * 4)  # 注意拼接后的通道数
        self.up3 = nn.ConvTranspose2d(base_ch * 4, base_ch * 4, 2, stride=2)

        self.dec2 = UNetBlock(base_ch * 4 * 2, base_ch * 2)
        self.up2 = nn.ConvTranspose2d(base_ch * 2, base_ch * 2, 2, stride=2)

        self.dec1 = UNetBlock(base_ch * 2 * 2, base_ch)
        self.up1 = nn.ConvTranspose2d(base_ch, base_ch, 2, stride=2)

        # 最终输出层
        # 修正2: 调整最终层的输入通道数(拼接后的通道数)
        self.final = nn.Sequential(
            nn.Conv2d(base_ch * 2, base_ch, 3, padding=1),
            nn.BatchNorm2d(base_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(base_ch, 3, 1),
            nn.Tanh()  # 输出范围[-1,1]更稳定
        )

    def forward(self, img):
        # 编码路径
        e1 = self.enc1(img)
        p1 = self.pool(e1)
        e2 = self.enc2(p1)
        p2 = self.pool(e2)
        e3 = self.enc3(p2)
        p3 = self.pool(e3)
        e4 = self.enc4(p3)
        p4 = self.pool(e4)

        # 瓶颈层
        b = self.bottleneck(p4)

        # 解码路径
        d4 = self.dec4(b)
        d4_up = self.up4(d4)
        d4_concat = torch.cat([d4_up, e4], dim=1)
        d3 = self.dec3(d4_concat)
        d3_up = self.up3(d3)
        d3_concat = torch.cat([d3_up, e3], dim=1)
        d2 = self.dec2(d3_concat)
        d2_up = self.up2(d2)
        d2_concat = torch.cat([d2_up, e2], dim=1)
        d1 = self.dec1(d2_concat)
        d1_up = self.up1(d1)
        d1_concat = torch.cat([d1_up, e1], dim=1)

        # 最终输出
        out = self.final(d1_concat)
        return out


# 使用亚像素卷积的反卷积上采样
class SubpixelUpBlock(nn.Module):
    def __init__(self, in_ch, out_ch, scale_factor=2):
        super().__init__()
        self.conv = nn.Conv2d(in_ch, out_ch * (scale_factor ** 2), kernel_size=3, padding=1)
        self.pixel_shuffle = nn.PixelShuffle(scale_factor)
        self.act = nn.ReLU(inplace=True)  # 替换为ReLU并inplace=True

    def forward(self, x):
        x = self.conv(x)
        x = self.pixel_shuffle(x)
        return self.act(x)


class ResBlock(nn.Module):
    def __init__(self, in_ch, out_ch, k=3):
        super().__init__()
        pad = k // 2
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, k, padding=pad),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )
        self.deform_conv = nn.Conv2d(out_ch, out_ch, k, padding=pad)
        self.bn2 = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)
        self.shortcut = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 1),
            nn.BatchNorm2d(out_ch)
        ) if in_ch != out_ch else nn.Sequential()

    def forward(self, x):
        res = self.shortcut(x)
        x1 = self.conv1(x)
        x2 = self.deform_conv(x1)
        x3 = self.bn2(x2 + res)
        return self.relu(x3)


# 多尺度空洞卷积模块
class MultiScaleDilatedConv(nn.Module):
    """多尺度空洞卷积捕获纹理特征"""

    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.dila_rates = [1, 2, 4, 6]
        self.convs = nn.ModuleList()
        for rate in self.dila_rates:
            self.convs.append(
                nn.Sequential(
                    nn.Conv2d(in_ch, out_ch, kernel_size=3, dilation=rate, padding=rate),
                    nn.BatchNorm2d(out_ch),
                    nn.ReLU(inplace=True)
                )
            )
        self.fuse = nn.Sequential(
            nn.Conv2d(len(self.dila_rates) * out_ch, out_ch, kernel_size=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        outs = []
        for conv in self.convs:
            outs.append(conv(x))
        out = torch.cat(outs, dim=1)
        return self.fuse(out)


class EnhancedRefiner(nn.Module):
    def __init__(self, in_ch=3, base_ch=64):
        super().__init__()
        # 输入处理模块 - 加入多尺度空洞卷积
        self.input_block = nn.Sequential(
            MultiScaleDilatedConv(in_ch, base_ch),
            MultiScaleDilatedConv(base_ch, base_ch)
        )

        # 下采样路径
        self.down1 = nn.Sequential(
            nn.Conv2d(base_ch, base_ch, 3, stride=2, padding=1),
            MultiScaleDilatedConv(base_ch, base_ch)
        )
        self.down2 = nn.Sequential(
            nn.Conv2d(base_ch, base_ch * 2, 3, stride=2, padding=1),
            MultiScaleDilatedConv(base_ch * 2, base_ch * 2)
        )
        self.down3 = nn.Sequential(
            nn.Conv2d(base_ch * 2, base_ch * 4, 3, stride=2, padding=1),
            MultiScaleDilatedConv(base_ch * 4, base_ch * 4)
        )

        # FPN模块
        self.fpn1 = nn.Sequential(
            MultiScaleDilatedConv(base_ch * 4, base_ch * 4),
            nn.Conv2d(base_ch * 4, base_ch * 4, 1)
        )
        self.fpn2 = nn.Sequential(
            MultiScaleDilatedConv(base_ch * 2, base_ch * 2),
            nn.Conv2d(base_ch * 2, base_ch * 2, 1)
        )
        self.fpn3 = nn.Sequential(
            MultiScaleDilatedConv(base_ch, base_ch),
            nn.Conv2d(base_ch, base_ch, 1)
        )

        # 特征融合层
        self.fpn1_to2 = nn.Sequential(
            nn.Conv2d(base_ch * 4, base_ch * 2, 1),
            nn.ReLU(inplace=True)
        )
        self.fpn2_to1 = nn.Sequential(
            nn.Conv2d(base_ch * 2, base_ch, 1),
            nn.ReLU(inplace=True)
        )

        # 添加特征金字塔融合层（fpn_fusion）
        self.fpn_fusion = nn.Conv2d(128, base_ch, 1)  # 添加这一行：128 -> base_ch (64) 通道

        # 上采样路径 - 重新设计以适应实际通道数
        self.up1 = SubpixelUpBlock(base_ch * 4, base_ch * 4)  # 输入256，输出256
        # 调整为接收384通道输入
        self.up2 = SubpixelUpBlock(384, base_ch * 2)  # 输入384，输出128
        # 修改上采样模块3的输入通道数：128 + 64 = 192 -> 192
        self.up3 = nn.Sequential(
            nn.Conv2d(192, base_ch * 2, 3, padding=1),  # 192 -> 128
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            nn.ReLU(inplace=True)
        )

        # 修改最终融合层的输入通道数：128 + 64 = 192 -> 192
        self.fusion_conv = nn.Conv2d(192, base_ch, kernel_size=1)

    def forward(self, x):
        x0 = self.input_block(x)  # (B, base_ch, H, W)

        x1 = self.down1(x0)  # (B, base_ch, H/2, W/2)
        x2 = self.down2(x1)  # (B, base_ch*2, H/4, W/4)
        x3 = self.down3(x2)  # (B, base_ch*4, H/8, W/8)

        # 特征金字塔处理
        f3 = self.fpn1(x3)  # (B, base_ch*4, H/8, W/8)
        f3_up = F.interpolate(self.fpn1_to2(f3), scale_factor=2, mode='bilinear', align_corners=True)

        f2 = self.fpn2(x2)  # (B, base_ch*2, H/4, W/4)
        f2_fused = f2 + f3_up  # 128 + 128 = 256? -> 不，应该是128通道，因为f3_up是128通道

        f2_up = F.interpolate(self.fpn2_to1(f2_fused), scale_factor=2, mode='bilinear', align_corners=True)
        f1 = self.fpn3(x1)  # (B, base_ch, H/2, W/2)

        # 多层特征融合
        fused_features = torch.cat([f1, f2_up], dim=1)  # (B, 64+64=128, H/2, W/2)
        fused_features = self.fpn_fusion(fused_features)  # (B, 64, H/2, W/2)

        # 上采样路径
        u3 = self.up1(f3)  # (B, 256, H/4, W/4)
        u3_cat = torch.cat([u3, f2_fused], dim=1)  # (B, 256+128=384, H/4, W/4)
        u2 = self.up2(u3_cat)  # (B, 128, H/2, W/2)

        u2_cat = torch.cat([u2, fused_features], dim=1)  # (B, 128+64=192, H/2, W/2)
        u1 = self.up3(u2_cat)  # (B, 128, H, W)

        u1_cat = torch.cat([u1, x0], dim=1)  # (B, 128+64=192, H, W)
        return self.fusion_conv(u1_cat)  # (B, 64, H, W)


class GlobalRefiner(nn.Module):
    def __init__(self, in_ch=64, base_ch=64):
        super().__init__()
        # 输入处理
        self.enc1 = UNetBlock(in_ch, base_ch)
        self.enc2 = UNetBlock(base_ch, base_ch * 2)
        self.pool = nn.MaxPool2d(2)
        self.bottleneck = UNetBlock(base_ch * 2, base_ch * 4)
        self.center = UNetBlock(base_ch * 4, base_ch * 4)

        # 使用亚像素卷积替代反卷积
        self.up2 = SubpixelUpBlock(base_ch * 4, base_ch * 2, scale_factor=2)  # 亚像素卷积上采样
        self.dec2 = UNetBlock(base_ch * 4, base_ch * 2)

        self.up1 = SubpixelUpBlock(base_ch * 2, base_ch, scale_factor=2)  # 亚像素卷积上采样
        self.dec1 = UNetBlock(base_ch * 2, base_ch)

        self.final = nn.Sequential(
            nn.Conv2d(base_ch, 3, 1),
            nn.ReLU(inplace=True)  # 确保输出范围[0,1]
        )

    def forward(self, x_feat):
        # x_feat: [B,64,512,512]
        e1 = self.enc1(x_feat)  # [B,64->64,512,512]
        e2 = self.enc2(self.pool(e1))  # [B,64->128,256,256]
        b = self.bottleneck(self.pool(e2))  # [B,128->256,128,128]
        c = self.center(b)  # [B,256,128,128]

        # 使用亚像素卷积上采样
        d2_up = self.up2(c)  # 上采样到256x256，通道数128
        d2 = self.dec2(torch.cat([d2_up, e2], dim=1))  # [B,128+128->128,256,256]

        d1_up = self.up1(d2)  # 上采样到512x512，通道数64
        d1 = self.dec1(torch.cat([d1_up, e1], dim=1))  # [B,128+64->64,512,512]

        return self.final(d1)  # [B,3,512,512]


# ----------------------- 加载模型 -----------------------
def load_models():
    """加载所有训练好的模型"""
    # 第一阶段修复模型
    G1 = DeepUNetGenerator().to(DEVICE)
    if os.path.exists(PHASE1_MODEL_PATH):
        G1.load_state_dict(torch.load(PHASE1_MODEL_PATH, map_location=DEVICE))
        print("已加载第一阶段模型")
    else:
        print(f"警告: 第一阶段模型文件 {PHASE1_MODEL_PATH} 不存在!")
    G1.eval()

    # 融合模型中的MSR
    MSR = None
    if os.path.exists(MSR_MODEL_PATH):
        MSR = EnhancedRefiner().to(DEVICE)
        MSR.load_state_dict(torch.load(MSR_MODEL_PATH, map_location=DEVICE))
        print("已加载MSR融合模型")
        MSR.eval()
    else:
        print(f"警告: MSR融合模型文件 {MSR_MODEL_PATH} 不存在!")

    # 融合模型中的G3
    G3 = None
    if os.path.exists(G3_MODEL_PATH):
        G3 = GlobalRefiner().to(DEVICE)
        G3.load_state_dict(torch.load(G3_MODEL_PATH, map_location=DEVICE))
        print("已加载G3融合模型")
        G3.eval()
    else:
        print(f"警告: G3融合模型文件 {G3_MODEL_PATH} 不存在!")

    return G1, MSR, G3


# ----------------------- 图像预处理 -----------------------
def preprocess_image(image_path):
    """加载并预处理图像"""
    image = Image.open(image_path).convert('RGB')
    orig_width, orig_height = image.size

    # 调整尺寸
    transform = transforms.Compose([
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.ToTensor(),  # 自动转换为[0,1]
    ])

    image_tensor = transform(image).unsqueeze(0).to(DEVICE)
    return image_tensor, orig_width, orig_height


# ----------------------- 修复图像 -----------------------
def inpaint_image(models, image_tensor):
    """使用模型修复图像并返回两个阶段的结果"""
    G1, MSR, G3 = models

    with torch.no_grad():
        # 第一阶段修复
        stage1_output = G1(image_tensor)

        # 转换第一阶段输出为图像
        stage1_img = stage1_output.squeeze(0).detach().cpu()
        stage1_img = stage1_img.permute(1, 2, 0).clamp(0, 1).numpy()
        stage1_img = (stage1_img * 255).astype(np.uint8)

        # 如果有融合模型，使用它们
        if MSR is not None and G3 is not None:
            msr_feat = MSR(stage1_output)
            final_output = G3(msr_feat)
        else:
            final_output = stage1_output

        # 转换最终输出为图像 - 修复版：移除反归一化
        final_img = final_output.squeeze(0).detach().cpu()
        final_img = final_img.permute(1, 2, 0).clamp(0, 1).numpy()
        final_img = (final_img * 255).astype(np.uint8)

        return stage1_img, final_img

# ----------------------- 创建可视化对比图 -----------------------
def create_visualization(original, mask, corrupted, stage1_output, final_output, save_path):
    """创建包含多个图像的可视化对比图"""
    plt.figure(figsize=(20, 8))

    # 1. 原始输入图像
    plt.subplot(1, 5, 1)
    plt.imshow(original)
    plt.title('Input Image')
    plt.axis('off')

    # 2. 生成的随机掩膜
    plt.subplot(1, 5, 2)
    plt.imshow(mask, cmap='gray')
    plt.title('Mask')
    plt.axis('off')

    # 3. 输入掩膜叠加后的残缺图 (黑色遮挡)
    plt.subplot(1, 5, 3)
    plt.imshow(corrupted)
    plt.title('Corrupted Image')
    plt.axis('off')

    # 4. 第一阶段模型的输出图
    plt.subplot(1, 5, 4)
    plt.imshow(stage1_output)
    plt.title('Stage1 Output')
    plt.axis('off')

    # 5. 最后模型的输出图
    plt.subplot(1, 5, 5)
    plt.imshow(final_output)
    plt.title('Final Output')
    plt.axis('off')

    # 保存和关闭
    plt.tight_layout()
    plt.savefig(save_path, bbox_inches='tight', dpi=200)
    plt.close()


# ----------------------- 主测试函数 -----------------------
def main():
    # 加载模型
    models = load_models()

    # 获取测试图像
    test_images = sorted(glob(os.path.join(TEST_DIR, '*.jpg')) +
                         glob(os.path.join(TEST_DIR, '*.png')) +
                         glob(os.path.join(TEST_DIR, '*.jpeg')))

    if not test_images:
        print(f"在 {TEST_DIR} 目录中未找到测试图像!")
        return

    print(f"开始处理 {len(test_images)} 张测试图像...")
    print(f"真值图目录: {TRUE_DIR}")

    for img_path in test_images:
        img_name = os.path.basename(img_path)
        base_name = os.path.splitext(img_name)[0]
        print(f"处理图像: {img_name}")

        # 查找对应的真值图
        true_path = find_true_mask(img_name)
        if true_path:
            print(f"使用真值图: {os.path.basename(true_path)}")
            # 读取真值图并转换为二值掩膜
            tgt_img = Image.open(true_path).convert('RGB')
            tgt_np = np.array(tgt_img)
            gt_mask = (np.max(tgt_np, axis=2) > 0).astype(np.uint8)
            gt_mask = cv2.resize(gt_mask, (IMG_W, IMG_H), interpolation=cv2.INTER_NEAREST)
        else:
            print(f"警告: 未找到 {img_name} 的真值图，将在整个图像上生成随机掩膜")
            gt_mask = None  # 在random_mask函数中会处理

        # 预处理图像
        input_tensor, orig_w, orig_h = preprocess_image(img_path)
        input_image = cv2.cvtColor(cv2.imread(img_path), cv2.COLOR_BGR2RGB)
        input_image = cv2.resize(input_image, (IMG_SIZE, IMG_SIZE))

        # 使用真值图生成随机遮罩
        mask = random_mask(gt_mask)

        # 应用遮罩到输入张量（生成损坏图像）
        mask_tensor = torch.from_numpy(mask).to(DEVICE)
        mask_tensor = mask_tensor.unsqueeze(0).unsqueeze(0).float()
        corrupted_tensor = input_tensor.clone()
        corrupted_tensor = corrupted_tensor * (1 - mask_tensor)

        # 可视化处理
        corrupted_image = corrupted_tensor.squeeze(0).detach().cpu()
        corrupted_image = corrupted_image.permute(1, 2, 0).numpy()
        corrupted_image = (corrupted_image * 255).astype(np.uint8)
        mask_np = mask.astype(bool)
        corrupted_image[mask_np] = 0

        # 修复图像（返回两个阶段的结果）
        stage1_result, final_result = inpaint_image(models, corrupted_tensor)

        # 调整所有图像到原始尺寸
        stage1_vis = cv2.resize(stage1_result, (orig_w, orig_h), interpolation=cv2.INTER_AREA)
        final_vis = cv2.resize(final_result, (orig_w, orig_h), interpolation=cv2.INTER_AREA)
        orig_vis = cv2.resize(input_image, (orig_w, orig_h))
        mask_vis = cv2.resize(mask, (orig_w, orig_h), interpolation=cv2.INTER_NEAREST)
        corrupted_vis = cv2.resize(corrupted_image, (orig_w, orig_h), interpolation=cv2.INTER_AREA)

        # 保存损坏图到input3目录
        input3_path = os.path.join(INPUT3_DIR, img_name)
        Image.fromarray(corrupted_vis).save(input3_path)
        print(f"保存损坏图到: {input3_path}")

        # 保存阶段1输出到phase1目录
        phase1_path = os.path.join(PHASE1_DIR, img_name)
        Image.fromarray(stage1_vis).save(phase1_path)
        print(f"保存阶段1输出到: {phase1_path}")


        # 保存最终输出
        final_path = os.path.join(PRED_DIR, f"{base_name}_final.png")
        Image.fromarray(final_vis).save(final_path)

        # 保存掩膜
        mask_path = os.path.join(MASK_DIR, f"{base_name}_mask.png")
        Image.fromarray((mask_vis * 255).astype(np.uint8)).save(mask_path)

        # 创建可视化对比图
        vis_path = os.path.join(VIS_DIR, f"{base_name}_visual.png")
        create_visualization(
            original=orig_vis,
            mask=mask_vis,
            corrupted=corrupted_vis,
            stage1_output=stage1_vis,
            final_output=final_vis,
            save_path=vis_path
        )

    print("测试完成! 结果已保存至:")
    print(f"- 损坏图像: {INPUT3_DIR}")
    print(f"- 阶段1输出: {PHASE1_DIR}")
    print(f"- 修复图像: {PRED_DIR}")
    print(f"- 遮罩图像: {MASK_DIR}")
    print(f"- 可视化对比: {VIS_DIR}")


if __name__ == "__main__":
    main()